var parent = document.getElementById("parent");
var showSlide = document.getElementById("showSlide");
var images = parent.getElementsByTagName("IMG");
var indexNum =0;
function renderSlide(){
    showSlide.src = images[indexNum].src;
}
renderSlide();

function nextSlide(){
    if((indexNum+1) == images.length){
        indexNum = 0;

    }else{
        indexNum++;
    }
    renderSlide();
}
function previousSlide(){
    if(indexNum == 0){
        indexNum = (images.length - 1);
    }else{
        indexNum--;
    }
    renderSlide();
}

setInterval(function(){
    nextSlide();
},3000)